
APP_NAME = 'Screenkey'
APP_DESC = 'Screencast your keys'
APP_URL = 'http://launchpad.net/screenkey'
VERSION = '0.2'
AUTHOR = 'Pablo Seminario'

